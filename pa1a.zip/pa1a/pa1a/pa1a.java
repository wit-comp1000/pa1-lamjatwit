package pa1a;
import java.util.Scanner;
public class pa1a{
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		int yards;
		int feet;
		int inches;
		System.out.println("enter number of yards: ");
		yards = input.nextInt();
		System.out.println("enter number of feet: ");
		feet = input.nextInt();
		System.out.println("enter number of inches: ");
		inches = input.nextInt();
		int yardIntoInches = yards * 36;
		int feetIntoInches = feet *12;
		int totalInches = yardIntoInches + feetIntoInches + inches;
		System.out.println("Total Inches: "+ totalInches);
	
	}
}