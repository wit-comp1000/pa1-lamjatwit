package pa1b;
import java.util.Scanner;
public class pa1b{
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		int totalInches;
		System.out.println("Enter number of inches: ");
		totalInches = input.nextInt();
		int yards = totalInches/36;
		System.out.println("Yards: "+ yards);
		int feet = (totalInches - (yards*36))/12;
		System.out.println("Feet: "+ feet);
		int leftoverInches = totalInches - (yards*36)-(feet*12);
		System.out.println("Inches: "+ leftoverInches);
		
	}
	
}